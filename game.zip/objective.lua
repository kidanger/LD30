local Objective = class 'Objective'

function Objective:init(expl, condition)
	self.expl = expl
	self.condition = condition
end

return Objective

